<?php


$firm_activity_api = "http://sdc.smartwebsource.net/api/v1/firm-activities?token=HDZ5HTKE9jiBJURKjQZsLnmSeAkJFadQ";
$single_firm_activity_api = "http://sdc.smartwebsource.net/api/v1/firm-activities?token=HDZ5HTKE9jiBJURKjQZsLnmSeAkJFadQ&frn=";
$open_cage_data_api_key = "72cffb19cf0b4317a0ede2b3f96a8df9";  // Your OpenCage API key for map location "https://api.opencagedata.com"
$geocoding = [];
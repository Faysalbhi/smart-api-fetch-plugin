<?php

// wp_clear_scheduled_hook( 'sdf_daily_fetch_cron' );
// wp_clear_scheduled_hook( 'sdf_process_fetched_data_cron' );
// do_action( 'sdf_daily_fetch_cron' );
// do_action( 'sdf_process_fetched_data_cron' );